effect_create_above(ef_firework, x, y, 1, c_white);
instance_destroy();
Obj_game_L2.alarm[0] = 120;