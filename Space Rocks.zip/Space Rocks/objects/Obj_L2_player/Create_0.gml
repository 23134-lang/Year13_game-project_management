powerup = 0;
iframes = 0;
weapon = 0;