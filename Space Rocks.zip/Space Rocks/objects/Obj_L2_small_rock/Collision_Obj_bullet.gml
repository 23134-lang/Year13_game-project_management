instance_destroy(other);
effect_create_above(ef_explosion, x, y, 1, c_white);

direction = random(360);

 if instance_number(Obj_small_rock) < 12
{
        sprite_index = spr_rock_big;
        x = -100;
}
else
{
        instance_destroy();
}
Obj_game.points += 25;