room_goto(Rm_game_L2);
