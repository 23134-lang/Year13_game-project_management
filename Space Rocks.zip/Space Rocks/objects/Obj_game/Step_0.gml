if (room == Rm_game && points >= 2000) {
	room_goto(Rm_game_L2)
}