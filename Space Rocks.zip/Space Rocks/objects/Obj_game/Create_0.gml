points = 0;
lives = 3;