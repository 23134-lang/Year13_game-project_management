speed = 10;
direction = Obj_ship.image_angle;