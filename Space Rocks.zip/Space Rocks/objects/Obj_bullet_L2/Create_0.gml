speed = 10;
direction = Obj_L2_player.image_angle;